import csv
import collections


def check_duplicates():
    print("Check Duplicates")
    print("================")

    with open("finnish_corpus.csv", newline="") as csv_file:
        reader = csv.reader(csv_file, delimiter=",")

        sentences = []
        for row in reader:
            sentences.append(row[1])
        duplicates = [sentence for sentence, count in collections.Counter(sentences).items() if count > 1]

    if len(duplicates) == 0:
        print("OK")
    else:
        for duplicate in duplicates:
            print(duplicate)


def check_whitespace():
    print("")
    print("Check Whitespace")
    print("================")

    with open("finnish_corpus.csv", newline="") as csv_file:
        reader = csv.reader(csv_file, delimiter=",")

        whitespace_sentences = []
        for row in reader:
            raw = row[1]
            stripped = raw.strip()
            if len(raw) != len(stripped):
                whitespace_sentences.append(raw)

    if len(whitespace_sentences) == 0:
        print("OK")
    else:
        for whitespace_sentence in whitespace_sentences:
            print(whitespace_sentence)



def check_ending_character():
    print("")
    print("Check Ending Character")
    print("======================")

    with open("finnish_corpus.csv", newline="") as csv_file:
        has_header = csv.Sniffer().has_header(csv_file.read(1024))
        csv_file.seek(0)  # Rewind
        reader = csv.reader(csv_file, delimiter=",")
        if has_header:
            next(reader)  # Skip header row
        
        missing_ending_character_sentences = []
        for row in reader:
            raw = row[1]
            stripped = raw.strip()
            if stripped[-1] not in ".!?":
                missing_ending_character_sentences.append(raw)

    if len(missing_ending_character_sentences) == 0:
        print("OK")
    else:
        for missing_ending_character_sentence in missing_ending_character_sentences:
            print(missing_ending_character_sentence)


def main():
    check_duplicates()
    check_whitespace()
    check_ending_character()


if __name__ == "__main__":
    main()