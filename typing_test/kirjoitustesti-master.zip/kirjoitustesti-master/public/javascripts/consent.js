$('#back-btn').click(function () {
    document.location.href = "/";
});

$("html").on('keydown', function() {
});
