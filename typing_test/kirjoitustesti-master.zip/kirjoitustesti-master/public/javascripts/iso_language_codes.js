/**
 * Two-letter ISO 639-1 language codes
 * 
 * Source: https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
 */
var isoLanguageCodes = {
    "sv": {
        "name": "ruotsi",
        "nativeName": "svenska"
    },
    "se": {
        "name": "saame",
        "nativeName": "samegillii"
    },
    "fi": {
        "name": "suomi",
        "nativeName": "suomi, suomen kieli"
    },
    "ru": {
        "name": "venäjä",
        "nativeName": "русский язык"
    },
    "et": {
        "name": "viro",
        "nativeName": "eesti, eesti keel"
    }
};
