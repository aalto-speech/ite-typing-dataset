var keyboardApps = {
    "Thumbly": "Thumbly",
    "Phraseboard": "Phraseboard",
    "Gboard": "Gboard",
    "SwiftKey": "SwiftKey",
    "Minuum": "Minuum",
    "Go": "Go",
    "Touchpal": "Touchpal",
    "Clips": "Clips",
    "ai.type": "ai.type",
    "multiling o": "multiling o",
    "chrooma": "chrooma",
    "other": "Muu näppäimistösovellus"
};
