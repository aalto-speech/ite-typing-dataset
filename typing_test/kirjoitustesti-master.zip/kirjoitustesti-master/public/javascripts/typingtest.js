var TOTAL_SENTENCES = 15; // Number of sentences per participant
var sentenceCount = 0; // Current sentence
var logDataToBeSubmitted = []; // Log data to submit
var keypressCount = 0; // Count keypresses since last log data submission; too much data will be posted to the server if all data is sent at the end of the sentence
var keys = {};
var dev_orientation = {alpha:"", beta:"", gamma:""};
var device;

function isMobile(){
    var isMobile = false; //initiate as false
    // device detection
    if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) { 
        isMobile = true;
    }
    return isMobile;
}

$(document).ready(function() {
    device = isMobile() ? 'mobile' : 'desktop';

    var $testInput = $('#test-input');
    var $errorRate = $('#error-rate');
    var $nextBtn = $('#next-btn');

    var processing = false;

    function parseError(msg) {
        var error = JSON.parse(msg.responseText).error;
        if (error === "uid_missing_err" || error === "tsid_missing_err") {
            document.location.href = "assets/session_err.html";
            return;
        }
        else {
            console.error("Unknown error");
        }
    }

    getNewSentence(true);

    matchBoxes();

    $testInput.focus();

    function getNewSentence(first) {
        if (first) {
            typingtestRoutes.controllers.TypingTest.getWPM().ajax({
                success: function (result) {
                    $('#wpm').html(parseInt(result.wpm));
                },
                error: function(error) {
                    parseError(error);
                }
            });
            typingtestRoutes.controllers.TypingTest.getErrorRate().ajax({
                success: function (result) {
                    $errorRate.html(result.errorRate.toFixed(2) + "%");
                    if (result.errorRate > 5) {
                        $errorRate.css("color", "red");
                    }
                    else {
                        $errorRate.css("color", "#4747a3");
                    }
                },
                error: function(error) {
                    parseError(error);
                }
            });
        }

        typingtestRoutes.controllers.TypingTest.sentence(first).ajax({
            success: function (result) {
                $('#test-sentence').text(result.sentence);
                $('#test-input').height( $('#test-sentence').height() );
                sentenceCount = parseInt(result.count);
                $('#sentence-count').html(sentenceCount.toString() + "/" + TOTAL_SENTENCES.toString());
            },
            error: function(error) {
                parseError(error);
            }
        });
    }

    $nextBtn.click(function () {
        setTimeout(testSectionEnd, 100);
        $testInput.focus();
    });

    $testInput.bind("paste", function (event) {
        event.preventDefault();
    });

    function testSectionEnd() {
        if ($testInput.val() === "") {
            return;
        }
        processing = true;
        $.mobile.loading("show");
        $nextBtn.attr('disabled', true);
        $nextBtn.addClass('disabled');
        $testInput.attr('disabled', true);
        $('#test-sentence').val('');
        var input = $testInput.val().trim(); // on iPhone: double space = period + space. People use it a lot to enter a period at the end of a sentence, but they don't erase the extra space manually.
        $testInput.val("");
        keypressCount = 0;
        setTimeout(
            saveLogData(
                function() {
                    saveUserInput(input);
                }
            ),
            50
        );
    }


    // Order of events: keydown, keypress, input, keyup
    $testInput.on("keydown", function(event) { // fired when a key is pressed for all keys, regardless of whether they produce a character value
        var time = $.now();
        if (processing === false && event.which !== 13) { // ignore "Enter" from logs; no need to log "Enter" events
            keys[event.which] = true;
            logDataToBeSubmitted.push(getData(event, time, $testInput.val()));
        }
    });

    $testInput.on("keypress", function(event) { // fired when a key that produces a character value is pressed down
        var time = $.now();
        if (processing === false && event.which === 13) { // user finished the sentence
            event.preventDefault();
            testSectionEnd();
        }
        else if (processing === false && event.which !== 13) { // ignore "Enter" from logs; no need to log "Enter" events
            logDataToBeSubmitted.push(getData(event, time, $testInput.val()));
            keypressCount++;
        }
    });

    $testInput.on("input", function(event) { // fired when the value of an input, select, or textarea element has been changed
        var time = $.now();
        if (processing === false && event.which !== 13) { // ignore "Enter" from logs; no need to log "Enter" events
            logDataToBeSubmitted.push(getData(event, time, $testInput.val()));
        }
    });

    $testInput.on("keyup", function(event) { // fired when a key is released
        var time = $.now();
        if (processing === false && event.which !== 13) { // ignore "Enter" from logs; no need to log "Enter" events
            keys[event.which] = false;
            logDataToBeSubmitted.push(getData(event, time, $testInput.val()));
        }

        if (keypressCount >= 5) {
            keypressCount = 0;
            saveLogData(function() {});
        }
    });

    function saveUserInput(input) {
        $.ajax('userInput', {
            url: 'userInput',
            type: 'POST',
            contentType: 'application/json; charset=UTF-8',
            dataType: 'json',
            data: JSON.stringify({
                userInput: input,
                device : device
            }),
            success: function(data) {
                if(sentenceCount >= TOTAL_SENTENCES) {
                    typingtestRoutes.controllers.TypingTest.updateStats().ajax({
                        success: function(data) {
                            if (data.questionnaire === "true") {
                                document.location.href = "results";
                            }
                            else {
                                document.location.href = "questionnaire";
                            }
                        },
                        error: function(error) {
                            parseError(error);
                        }
                    });

                    return;
                }

                // Update WPM
                typingtestRoutes.controllers.TypingTest.getWPM().ajax({
                    success: function(data) {
                        $('#wpm').html(parseInt(data.wpm));
                    },
                    error: function(error) {
                        parseError(error);
                    }
                });

                // Update error rate
                typingtestRoutes.controllers.TypingTest.getErrorRate().ajax({
                    success: function(data) {
                        $errorRate.html(data.errorRate.toFixed(2) + "%");
                        if (data.errorRate > 5) {
                            $errorRate.css('color', 'red');
                        }
                        else if (data.errorRate <= 5) {
                            $errorRate.css('color', '#4747a3');
                        }

                        // Get new sentence
                        getNewSentence(false);
                    },
                    error: function(error) {
                        parseError(error);
                    }
                });

            },
            error: function(error) {
                parseError(error);
            },
            complete: function() {
                $testInput.attr('disabled', false);
                $nextBtn.attr('disabled', false);
                $nextBtn.removeClass('disabled');
                $testInput.focus();
                $.mobile.loading("hide");
                processing = false;
            }
        });
    }
});

function getData(event, time, input) {
    return {
        eventTimestamp: time,
        eventType: String(event.type),
        eventKey: String(event.originalEvent.key),
        eventCode: String(event.originalEvent.code),
        eventData: String(event.originalEvent.data) || '',
        inputText: String(input),
        keyCodes: String(whichPressed(keys)),
        screenOrientation: JSON.stringify(getScreenOrientation()),
        deviceOrientation: JSON.stringify(getDeviceOrientation())
    };
}

function getDeviceOrientation() {
    return dev_orientation;
}

function whichPressed(keys) {
    var pressed = [];
    for (var k in keys) {
        if (keys[k] === true) {
            pressed.push(k);
        }
    }

    return pressed;
}

function saveLogData(callback) {
    var ld = logDataToBeSubmitted.slice(0);
    logDataToBeSubmitted = [];
    $.ajax('logData', {
        url: 'logData',
        type: 'POST',
        contentType: 'application/json; charset=UTF-8',
        dataType: 'json',
        data: JSON.stringify({logData: ld }),
        success: callback,
        error: function(error) {
            console.error(error);
        }
    });
}

function matchBoxes(){
    if (isMobile()){
        //var orient = getScreenOrientation();
        if (window.orientation == 90){
            //$('#test-input').offset({top : offset_top})
            $('#input-row .test-field').offset(
                { 
                    top: $('#sentence-row .test-field').offset().top 
                });
            $('#input-row .test-field').height($('#sentence-row .test-field').height());

        } else {
            $('#input-row .test-field').offset(
                { 
                    top : ($('#sentence-row .test-field').offset().top + $('#sentence-row .test-field').height() + 25)
                });
        }
    }
}

/**
 * Returns 0 for portrait, 90 for landscape
 */
function getScreenOrientation(){
    if (typeof(screen.orientation) != "undefined") {
        return screen.orientation.angle;
    }

    if (typeof(window.orientation) != "undefined") {
        return window.orientation;
    }
    else {
        return -1;
    }
}

if (isMobile()) {
    window.addEventListener('deviceorientation', function(event) {
        dev_orientation.alpha = parseFloat(event.alpha).toFixed(2);
        dev_orientation.beta = parseFloat(event.beta).toFixed(2);
        dev_orientation.gamma = parseFloat(event.gamma).toFixed(2);
    });

    window.addEventListener("orientationchange", function() {
        setTimeout(function(){ 
            matchBoxes();
        }, 400);
    });
}
