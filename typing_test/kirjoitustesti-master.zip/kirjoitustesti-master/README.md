# Kirjoitustesti (Finnish version of Typing Test)

This repository contains typing speed test application for Finnish language. The source code is the updated version of the typing test application which has been previously used to collect large sets of observations for typing on [a physical keyboard](https://userinterfaces.aalto.fi/136Mkeystrokes/) and on [mobile devices](https://userinterfaces.aalto.fi/typing37k/).
 
In this version, the code documentation has been improved and support for Finnish has been added. The code is also easier to import to other languages compared to previous versions.
 
Finnish corpus is sampled from [Yle News Archive Easy-to-read Finnish 2011-2018](http://urn.fi/urn:nbn:fi:lb-2019050902) by [Kielipankki](http://kielipankki.fi). Random sampling was restricted by the length of the words and sentences and the frequency of the word. The aim of the restrictions was to select a simple and short sentences which are easy to read and remember.


## Technologies

Main technologies and libraries used in the project.

### Database

- **MySQL (v5.7.23).** Relational database management system. https://www.mysql.com/

### Backend

- **Java (v1.8.0_221).** General-purpose programming language. https://www.java.com/
- **Scala (v2.11.7).** General-purpose programming language. https://www.scala-lang.org/
- **sbt (v0.13.11).** Build tool for Scala and Java projects. https://www.scala-sbt.org/
- **Play Framework (v2.5.3).** Web application framework for Java and Scala. https://www.playframework.com/

### Frontend

- **jQuery (v2.2.3).** Cross-platform JavaScript library. https://jquery.com/
- **jQuery mobile (v1.4.5).** Touch-Optimized Web Framework. https://jquerymobile.com/
- **jQuery validation (v1.16.0).** jQuery plugin for easy and quick form validation using data attributes. https://jqueryvalidation.org/
- **Bootstrap (v3.3.7 / v4.1.1).** Front-end web framework for developing responsive, mobile-first projects. https://getbootstrap.com/
- **Swiper (v4.3.3).** Modern mobile touch slider. http://idangero.us/swiper/
- **Chart (v2.7.2).** Simple yet flexible JavaScript charting for designers & developers. http://chartjs.org/
- **UA parser (v0.7.10).** User-Agent string parser. https://github.com/faisalman/ua-parser-js


## Installation

Clone the git repository:
```
git clone git@version.aalto.fi:typing/kirjoitustesti.git
cd kirjoitustesti
```


## Configuration

### Database

Initialize the database structure and data by importing [database/database_init_structure_and_data.sql](./database/database_init_structure_and_data.sql). Alternatively, initialize the database structure and/or data only by importing [database/database_init_structure_only.sql](./database/database_init_structure_only.sql) and/or [database/database_init_data_only.sql](./database/database_init_data_only.sql), respectively.

The database table descriptions are available in [database/database_table_descriptions.json](./database/database_table_descriptions.json). 

### Backend

Configure the application's (1) *Secret key*, (2) JDBC Datasource's *url*, *user*, and *password*, and (3) Typing Test's *averageWordLength* by editing [conf/application.conf](./conf/application.conf).

### Frontend

Configure *TOTAL_SENTENCES* for the typing test by editing [public/javascripts/typingtest.js](./public/javascripts/typingtest.js).


## Usage

Launch *sbt* in interactive mode, i.e., the *sbt* console:
```
sbt
```

The following commands work only when executed in the *sbt* console.

Show the project information:
```
about
```

Run the application, with auto reloading enabled (for development):
```
run 9001
```

Open <http://localhost:9001/> in your favorite web browser to interact with the application.

Build a binary version of the application (within a distributable zip file):
```
dist
```

Exit the *sbt* console:
```
exit
```


## Deployment

Step by step instructions for deploying *kirjoitustesti* to the production server:

1. Connect to the production server as *typingmaster*: `ssh typingmaster@195.148.124.207`
2. Clone the *kirjoitustesti* git repository into *typingmaster*'s home directory (done only once): `git clone git@version.aalto.fi:typing/kirjoitustesti.git`
3. Go to the *kirjoitustesti* project directory: `cd kirjoitustesti`
4. Update the project: `git pull`
5. Launch the *sbt* shell: `sbt`
6. Build the distribution package: `dist`
7. Exit the *sbt* shell: `exit`
8. Copy the distribution package into the www directory: `cp /home/typingmaster/kirjoitustesti/target/universal/kirjoitustesti-1.0.0.zip /var/www/kirjoitustesti/`
9. Go to the *kirjoitustesti* www directory: `cd /var/www/kirjoitustesti/`
10. Stop the *kirjoitustesti* application server: `./stop`
11. Remove the old *kirjoitustesti* application files: `rm -rf kirjoitustesti-1.0.0`
12. Unzip the distribution package: `unzip kirjoitustesti-1.0.0.zip`
13. Start the *kirjoitustesti* application server: `./start`

Log files folder: `/var/www/kirjoitustesti/logs/`

Production server configuration file: `/var/www/kirjoitustesti/production.conf`


## FAQ

A list of most common problems and solutions to overcome them.

### Problem 1

The following error message appears upon executing `sbt` in the console.
```
[ERROR] Failed to construct terminal; falling back to unsupported
java.lang.NumberFormatException: For input string: "0x100"
...
```

### Solution 1

Change the value of the **TERM** environment by executing the following command in the console:
```
export TERM=xterm-color
```


## License

This software is licensed under the [MIT License](https://opensource.org/licenses/MIT), see the [LICENSE.txt](./LICENSE.txt) file for details.

Copyright © 2019 [User Interfaces group](https://userinterfaces.aalto.fi/), [Aalto University](https://www.aalto.fi/), Finland
