package models

case class TestSection(
  id: Int,
  sentenceId: Int,
  participantId: Int,
  userInput: Option[String] = None,
  inputLength: Option[Int] = None,
  inputTime: Option[Long] = None,
  wpm: Option[Double] = None,
  errorLength: Option[Int] = None,
  editDistance: Option[Int] = None,
  errorRate: Option[Double] = None,
  device: Option[String] = None
)
