package models

case class LogData(
  id: Int = 0,
  testSectionId: Int,
  eventTimestamp: Long,
  eventType: String,
  eventKey: String,
  eventCode: String,
  eventData: String,
  inputText: String,
  keyCodes: String,
  screenOrientation: String,
  deviceOrientation: String
)
