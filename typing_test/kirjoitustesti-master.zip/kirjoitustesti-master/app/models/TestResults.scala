package models

case class TestResults(
  wpm: Double,
  errorRate: Double,
  maxErrorRateUserInput: Option[String],
  maxErrorRateSentence: Option[String],
  maxErrorRateEditDistance: Option[Int],
  maxErrorRateWpm: Option[Double],
  maxWpmUserInput: String,
  maxWpmEditDistance: Int,
  maxWpmWpm: Double,
  minWpmUserInput: String,
  minWpmEditDistance: Int,
  minWpmWpm: Double
)
