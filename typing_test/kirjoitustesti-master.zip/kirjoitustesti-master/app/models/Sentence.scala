package models

case class Sentence(
  id: Int,
  sentence: String,
  source: String
)
