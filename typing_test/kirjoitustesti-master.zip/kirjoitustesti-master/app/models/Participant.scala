package models

case class Participant(
  id: Int = 0,
  ipAddress: Option[String] = None,
  browserString: Option[String] = None,
  browserLanguage: Option[String] = None,
  device: Option[String] = None,
  screenW: Option[Int] = None,
  screenH: Option[Int] = None,
  age: Option[Int] = None,
  gender: Option[String] = None,
  hasTakenTypingCourse: Option[Boolean] = None,
  wpm: Option[Double] = None,
  errorRate: Option[Double] = None,
  nativeLanguage: Option[String] = None,
  keyboardType: Option[String] = None,
  usingApp: Option[String] = None,
  usingFeatures: Option[String] = None,
  fingers: Option[String] = None,
  timeSpentTyping: Option[Int] = None,
  typeTestLang: Option[String] = None
)
