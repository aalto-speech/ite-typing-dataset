package db

import javax.inject.{Inject, Singleton}
import models.Participant
import slick.driver.MySQLDriver.api._

object Participants {
  def participants = TableQuery[Participants]
}

// MAX NUM OF PARAMETERS IS 22 UNLESS YOU WANT A WORKAROUND
// https://stackoverflow.com/questions/20258417/how-to-get-around-the-scala-case-class-limit-of-22-fields

class Participants(tag: Tag) extends Table[Participant](tag, "PARTICIPANTS") {
  def id = column[Int]("PARTICIPANT_ID", O.PrimaryKey, O.AutoInc)
  def ipAddress = column[Option[String]]("IP_ADDRESS")
  def browserString = column[Option[String]]("BROWSER_STRING")
  def browserLanguage = column[Option[String]]("BROWSER_LANGUAGE")
  def device = column[Option[String]]("DEVICE")
  def screenW = column[Option[Int]]("SCREEN_W")
  def screenH = column[Option[Int]]("SCREEN_H")
  def age = column[Option[Int]]("AGE")
  def gender = column[Option[String]]("GENDER")
  def hasTakenTypingCourse = column[Option[Boolean]]("HAS_TAKEN_TYPING_COURSE")
  def wpm = column[Option[Double]]("WPM")
  def errorRate = column[Option[Double]]("ERROR_RATE")
  def nativeLanguage = column[Option[String]]("NATIVE_LANGUAGE")
  def keyboardType = column[Option[String]]("KEYBOARD_TYPE")
  def usingApp = column[Option[String]]("USING_APP")
  def usingFeatures = column[Option[String]]("USING_FEATURES")
  def fingers = column[Option[String]]("FINGERS")
  def timeSpentTyping = column[Option[Int]]("TIME_SPENT_TYPING")
  def typeTestLang = column[Option[String]]("TYPE_TEST_LANG")

  def * = (
    id,
    ipAddress,
    browserString,
    browserLanguage,
    device,
    screenW,
    screenH,
    age,
    gender,
    hasTakenTypingCourse,
    wpm,
    errorRate,
    nativeLanguage,
    keyboardType,
    usingApp,
    usingFeatures,
    fingers,
    timeSpentTyping,
    typeTestLang
  ) <> (Participant.tupled, Participant.unapply)
}
