package db

import javax.inject.{Inject, Singleton}
import models.Sentence
import slick.driver.MySQLDriver.api._

object Sentences {
  def sentences = TableQuery[Sentences]
}

class Sentences(tag: Tag) extends Table[Sentence](tag, "SENTENCES") {
  def id = column[Int]("SENTENCE_ID", O.PrimaryKey, O.AutoInc)
  def sentence = column[String]("SENTENCE")
  def source = column[String]("SOURCE")

  def * = (
    id,
    sentence,
    source
  ) <> (Sentence.tupled, Sentence.unapply)
}
