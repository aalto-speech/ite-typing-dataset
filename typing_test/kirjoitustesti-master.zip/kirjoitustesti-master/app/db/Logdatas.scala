package db

import javax.inject.{Inject, Singleton}
import models.LogData
import slick.driver.MySQLDriver.api._

object LogDatas {
  implicit val logDatas = TableQuery[LogDatas]
}

class LogDatas (tag: Tag) extends Table[LogData](tag, "LOG_DATA") {
  def id = column[Int]("LOG_DATA_ID", O.PrimaryKey, O.AutoInc)
  def testSectionId = column[Int]("TEST_SECTION_ID")
  def eventTimestamp = column[Long]("EVENT_TIMESTAMP")
  def eventType = column[String]("EVENT_TYPE")
  def eventKey = column[String]("EVENT_KEY")
  def eventCode = column[String]("EVENT_CODE")
  def eventData = column[String]("EVENT_DATA")
  def inputText = column[String]("INPUT_TEXT")
  def keyCodes = column[String]("KEY_CODES")
  def screenOrientation = column[String]("SCREEN_ORIENTATION")
  def deviceOrientation = column[String]("DEVICE_ORIENTATION")

  def testSectionFk = foreignKey("TEST_SECTION_FFK", testSectionId, TestSections.testSections)(_.id, onDelete = ForeignKeyAction.Cascade)

  def * = (
    id,
    testSectionId,
    eventTimestamp,
    eventType,
    eventKey,
    eventCode,
    eventData,
    inputText,
    keyCodes,
    screenOrientation,
    deviceOrientation
  ) <> (LogData.tupled, LogData.unapply)
}
