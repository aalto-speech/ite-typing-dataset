package db

import javax.inject.{Inject, Singleton}
import models.TestSection
import slick.driver.MySQLDriver.api._

object TestSections {
  implicit val testSections = TableQuery[TestSections]
}

class TestSections (tag: Tag) extends Table[TestSection](tag, "TEST_SECTIONS") {
  def id = column[Int]("TEST_SECTION_ID", O.PrimaryKey, O.AutoInc)
  def sentenceId = column[Int]("SENTENCE_ID")
  def participantId = column[Int]("PARTICIPANT_ID")
  def userInput = column[Option[String]]("USER_INPUT")
  def inputLength = column[Option[Int]]("INPUT_LENGTH")
  def inputTime = column[Option[Long]]("INPUT_TIME")
  def wpm = column[Option[Double]]("WPM")
  def errorLength = column[Option[Int]]("ERROR_LENGTH")
  def editDistance = column[Option[Int]]("EDIT_DISTANCE")
  def errorRate = column[Option[Double]]("ERROR_RATE")
  def device = column[Option[String]]("DEVICE")

  def participantFk = foreignKey("PARTICIPANT_FK", participantId, Participants.participants)(_.id, onDelete =  ForeignKeyAction.Cascade)
  def sentenceFk = foreignKey("SENTENCE_FK", sentenceId, Sentences.sentences)(_.id)

  def * = (
    id,
    sentenceId,
    participantId,
    userInput,
    inputLength,
    inputTime,
    wpm,
    errorLength,
    editDistance,
    errorRate,
    device
  ) <> (TestSection.tupled, TestSection.unapply)
}
