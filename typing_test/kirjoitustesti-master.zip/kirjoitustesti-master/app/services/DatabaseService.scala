package services

import javax.inject.{Inject, Singleton}

import db.Sentences.sentences
import db.TestSections.testSections
import db.Participants.participants
import db.LogDatas.logDatas
import models.{Participant, Sentence, TestSection, LogData}
import play.api.db.slick.DatabaseConfigProvider

import scala.concurrent.{Future, Promise}
import slick.driver.JdbcProfile
import slick.driver.MySQLDriver.api._

import scala.concurrent.ExecutionContext.Implicits.global

trait DatabaseService {
  def getRandomSentence(id: Int): Future[Seq[Sentence]]

  def updateDevice(testSectionId: Int, device: String): Future[Int]
  def updateUserInput(testSectionId: Int, userInput: String): Future[Int]
  def updateWpm(testSectionId: Int, inputLength: Int, inputTime: Long, wpm: Double): Future[Int]
  def updateErrorRate(testSectionId: Int, errorLength: Int, editDistance: Int, errorRate: Double): Future[Int]
  def updateBrowserData(participantId: Int, ipAddress: String, browserString: Option[String], browserLanguage: Option[String], device: Option[String], screenW: Option[Int], screenH: Option[Int]): Future[Int]
  def updatePersonalData(participantId: Int, age: Int, gender: String, hasTakenTypingCourse: Boolean, nativeLanguage: String, keyboardType: String, usingApp: String, usingFeatures: String, fingers: String, timeSpentTyping: Int, typeTestLang: String): Future[Int]
  def updateUserStats(participantId: Int, wpm: Double, errorRate: Double)

  def getTestSections(participantId: Int): Future[Seq[TestSection]]
  def getParticipantAge(participantId: Int): Future[Seq[(Option[Int])]]
  def getLogDatas(testSectionId: Int): Future[Seq[LogData]]
  def getDataForError(testSectionId: Int): Future[Seq[(Option[String], String)]]
  def getSentence(testSectionId: Int): Future[Seq[Sentence]]

  def getMaxErrorRate(participantId: Int): Future[Seq[(Option[String], String, Option[Int], Option[Double])]]
  def getMaxWpm(participantId: Int): Future[Seq[(Option[String], Option[Int], Option[Double])]]
  def getMinWpm(participantId: Int): Future[Seq[(Option[String], Option[Int], Option[Double])]]

  def addParticipant(p: Participant): Future[Int]
  def addTestSection(ts: TestSection): Future[Int]
  def addLogData(ld: Seq[LogData]): Future[Option[Int]]
  //def addOrientation(ld: Seq[Orientation]): Future[Option[Int]]
  def listTestSections(device: String): Future[Seq[TestSection]]
  def getWpmHistogramData(device: String): Future[Seq[(Int, Int)]]
  def getWpmAgeHistogramData(ageMin: Int, ageMax: Int, device: String): Future[Seq[(Int, Int)]]
  def getErrorRateHistogramData(device: String): Future[Seq[(Int, Int)]]
}

@Singleton
class DatabaseServiceImpl @Inject()(dbConfigProvider: DatabaseConfigProvider) extends DatabaseService {
  val dbConfig = dbConfigProvider.get[JdbcProfile]

  def getRandomSentence(id: Int): Future[Seq[Sentence]] = {
    val participantSentenceIds = for {
      (t, s) <- testSections join sentences on (_.sentenceId === _.id) if t.participantId === id
    } yield s.id
    val unusedSentences = sentences.filterNot(_.id in participantSentenceIds)
    val rand = SimpleFunction.nullary[Double]("rand")
    dbConfig.db.run(unusedSentences.sortBy(x => rand).take(1).result)
  }

  def updateDevice(testSectionId: Int, device: String): Future[Int] = {
    val q = for {
      ts <- testSections if ts.id === testSectionId
    } yield ts.device
    dbConfig.db.run(q.update(Some(device)))
  }

  def updateUserInput(testSectionId: Int, userInput: String): Future[Int] = {
    val q = for {
      ts <- testSections if ts.id === testSectionId
    } yield ts.userInput
    dbConfig.db.run(q.update(Some(userInput)))
  }

  def updateWpm(testSectionId: Int, inputLength: Int, inputTime: Long, wpm: Double): Future[Int] = {
    val q = for {
      ts <- testSections if ts.id === testSectionId
    } yield (ts.inputLength, ts.inputTime, ts.wpm)
    dbConfig.db.run(q.update(Some(inputLength), Some(inputTime), Some(wpm)))
  }

  def updateErrorRate(testSectionId: Int, errorLength: Int, editDistance: Int, errorRate: Double): Future[Int] = {
    val q = for {
      ts <- testSections if ts.id === testSectionId
    } yield (ts.errorLength, ts.editDistance, ts.errorRate)
    dbConfig.db.run(q.update(Some(errorLength), Some(editDistance), Some(errorRate)))
  }

  def updateBrowserData(participantId: Int, ipAddress: String, browserString: Option[String], browserLanguage: Option[String], device: Option[String], screenW: Option[Int], screenH: Option[Int]): Future[Int] = {
    val q = for {
      p <- participants if p.id === participantId
    } yield (p.ipAddress, p.browserString, p.browserLanguage, p.device, p.screenW, p.screenH)
    dbConfig.db.run(q.update(Some(ipAddress), browserString, browserLanguage, device, screenW, screenH))
  }

  def updatePersonalData(participantId: Int, age: Int, gender: String, hasTakenTypingCourse: Boolean, nativeLanguage: String, keyboardType: String, usingApp: String, usingFeatures: String, fingers: String, timeSpentTyping: Int, typeTestLang: String): Future[Int] = {
    val q = for {
      p <- participants if p.id === participantId
    } yield (p.age, p.gender, p.hasTakenTypingCourse, p.nativeLanguage, p.keyboardType, p.usingApp, p.usingFeatures, p.fingers, p.timeSpentTyping, p.typeTestLang)
    dbConfig.db.run(q.update(Some(age), Some(gender), Some(hasTakenTypingCourse), Some(nativeLanguage), Some(keyboardType), Some(usingApp), Some(usingFeatures), Some(fingers), Some(timeSpentTyping), Some(typeTestLang)))
  }

  def updateUserStats(participantId: Int, wpm: Double, errorRate: Double) = {
    val q = for {
      p <- participants if p.id === participantId
    } yield (p.wpm, p.errorRate)
    dbConfig.db.run(q.update(Some(wpm), Some(errorRate)))
  }

  def getTestSections(participantId: Int): Future[Seq[TestSection]] = {
    dbConfig.db.run(testSections.filter(_.participantId === participantId).filter(_.userInput.isDefined).result)
  }

  def getParticipantAge(participantId: Int): Future[Seq[(Option[Int])]] = {
    val q = for {
      p <- participants.filter(_.id === participantId)
    } yield (p.age)
    dbConfig.db.run(q.result)
  }

  def getLogDatas(testSectionId: Int): Future[Seq[LogData]] = {
    dbConfig.db.run(logDatas.filter(_.testSectionId === testSectionId).result)
  }

  def getSentence(testSectionId: Int): Future[Seq[Sentence]] = {
    val q = for {
      (ts, s) <- testSections join sentences on (_.sentenceId === _.id) if ts.id === testSectionId
    } yield s
    dbConfig.db.run(q.result)
  }

  def getMaxErrorRate(participantId: Int): Future[Seq[(Option[String], String, Option[Int], Option[Double])]] = {
    val q = for {
      max_ts <- testSections.filter(_.participantId === participantId).sortBy(_.errorRate.desc).take(1)
      s <- sentences.filter(_.id === max_ts.sentenceId)
    } yield (max_ts.userInput, s.sentence, max_ts.editDistance, max_ts.wpm)
    dbConfig.db.run(q.result)
  }

  def getMaxWpm(participantId: Int): Future[Seq[(Option[String], Option[Int], Option[Double])]] = {
    val q = for {
      max_ts <-testSections.filter(_.participantId === participantId).sortBy(_.wpm.desc).take(1)
    } yield (max_ts.userInput, max_ts.editDistance, max_ts.wpm)
    dbConfig.db.run(q.result)
  }

  def getMinWpm(participantId: Int): Future[Seq[(Option[String], Option[Int], Option[Double])]] = {
    val q = for {
      min_ts <-testSections.filter(_.participantId === participantId).sortBy(_.wpm.asc).take(1)
    } yield (min_ts.userInput, min_ts.editDistance, min_ts.wpm)
    dbConfig.db.run(q.result)
  }

  def addParticipant(p: Participant) = {
    dbConfig.db.run(participants returning participants.map(_.id) += p)
  }

  def addTestSection(ts: TestSection) = {
    dbConfig.db.run(testSections returning testSections.map(_.id) += ts)
  }

  def getDataForError(testSectionId: Int): Future[Seq[(Option[String], String)]] = {
    val q = for {
      (ts, s) <- testSections join sentences on(_.sentenceId === _.id) if ts.id === testSectionId
    } yield (ts.userInput, s.sentence)
    dbConfig.db.run(q.result)
  }

  def addLogData(ld: Seq[LogData]) = {
    dbConfig.db.run(logDatas ++= ld)
  }

  def listTestSections(device: String): Future[Seq[TestSection]] = {
    dbConfig.db.run(testSections.filter(_.device === device).filter(_.userInput.isDefined).result)
  }

  def getWpmHistogramData(device: String): Future[Seq[(Int, Int)]] = {
    val WPM_MAX_MOBILE: Int = 100
    val WPM_MAX_DESKTOP: Int = 150
    val WPM_MIN: Int = 0 // included
    val WPM_MAX: Int = if (device == "mobile") WPM_MAX_MOBILE else WPM_MAX_DESKTOP // excluded
    val WPM_STEP_SIZE: Int = 5
    dbConfig.db.run(sql"""SELECT FLOOR(WPM/$WPM_STEP_SIZE)*$WPM_STEP_SIZE AS bucket, COUNT(*) AS count FROM PARTICIPANTS WHERE WPM IS NOT NULL AND $WPM_MIN <= WPM AND WPM < $WPM_MAX AND DEVICE = $device GROUP BY bucket""".as[(Int, Int)])
  }

  def getWpmAgeHistogramData(ageMin: Int, ageMax: Int, device: String): Future[Seq[(Int, Int)]] = {
    val WPM_MAX_MOBILE: Int = 100
    val WPM_MAX_DESKTOP: Int = 150
    val WPM_MIN: Int = 0 // included
    val WPM_MAX: Int = if (device == "mobile") WPM_MAX_MOBILE else WPM_MAX_DESKTOP // excluded
    val WPM_STEP_SIZE: Int = 5
    dbConfig.db.run(sql"""SELECT FLOOR(WPM/$WPM_STEP_SIZE)*$WPM_STEP_SIZE AS bucket, COUNT(*) AS count FROM PARTICIPANTS WHERE WPM IS NOT NULL AND $WPM_MIN <= WPM AND WPM < $WPM_MAX AND $ageMin <= AGE AND AGE <= $ageMax AND DEVICE = $device GROUP BY bucket""".as[(Int, Int)])
  }

  def getErrorRateHistogramData(device: String): Future[Seq[(Int, Int)]] = {
    val ERROR_RATE_MAX_MOBILE: Int = 20
    val ERROR_RATE_MAX_DESKTOP: Int = 20
    val ERROR_RATE_MIN: Int = 0 // included
    val ERROR_RATE_MAX: Int = if (device == "mobile") ERROR_RATE_MAX_MOBILE else ERROR_RATE_MAX_DESKTOP // excluded
    val ERROR_RATE_STEP_SIZE: Int = 1
    dbConfig.db.run(sql"""SELECT FLOOR(ERROR_RATE/$ERROR_RATE_STEP_SIZE)*$ERROR_RATE_STEP_SIZE AS bucket, COUNT(*) AS count FROM PARTICIPANTS WHERE ERROR_RATE IS NOT NULL AND $ERROR_RATE_MIN <= ERROR_RATE AND ERROR_RATE < $ERROR_RATE_MAX AND DEVICE = $device GROUP BY bucket""".as[(Int, Int)])
  }
}
