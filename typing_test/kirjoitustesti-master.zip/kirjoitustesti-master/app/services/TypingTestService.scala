package services

import javax.inject._

import controllers.LogDataSubmit
import db.TestSections
import models.{Participant, TestSection, LogData}

import scala.Tuple2
import scala.concurrent.{Await, Future, Promise}
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import scala.math.min
import scala.util.{Failure, Success}

trait TypingTestService {
  def newUid(): Future[String]
  def newSentence(uid: String): Future[Map[String, String]]

  def getSentence(tsId: String): Future[Map[String, String]]
  def getAgeValues(uid: String): Future[(Int, Int, Int)]
  def getWPM(uid: String): Future[Double]
  def getErrorRate(uid: String): Future[Double]

  def getMaxErrorRate(uid: String): Future[(Option[String], Option[String], Option[Int], Option[Double])]
  def getMaxWpm(uid: String): Future[(Option[String], Option[Int], Option[Double])]
  def getMinWpm(uid: String): Future[(Option[String], Option[Int], Option[Double])]

  def updateUserStats(uid: String)

  def submitLogData(testSection: String, logDataSubmit: Seq[LogDataSubmit]): Future[Unit]

  def submitUserInput(tsId: String, userInput: String, device: String): Future[Unit]
  def submitBrowserData(uid: String, ipAddress: String, browserString: Option[String], browserLanguage: Option[String], device: Option[String], screenW: Option[Int], screenH: Option[Int]): Future[Unit] 
  def submitUserData(uid: String, age: Int, gender: String, hasTakenTypingCourse: Boolean, nativeLanguage: String, keyboardType: String, usingApp: String, usingFeatures: String, fingers: String, timeSpentTyping: Int, typeTestLang: String): Future[Unit]

  def getTestSections(device: String): Future[Seq[TestSection]]
  def getWpmHistogramData(device: String): Future[Seq[(Int, Int)]]
  def getWpmAgeHistogramData(ageMin: Int, ageMax: Int, device: String): Future[Seq[(Int, Int)]]
  def getErrorRateHistogramData(device: String): Future[Seq[(Int, Int)]]
}

@Singleton
class TypingTestServiceImpl @Inject() (configuration: play.api.Configuration, databaseService: DatabaseService, cryptoService: CryptoService) extends TypingTestService {

  /**
   * Calculates words per minute (WPM).
   *
   * @param inputLength   The length of the final transcribed string (T) entered by the subject. T may contain letters, numbers, punctuation, spaces, and other printable characters, but not backspaces.
   * @param inputTime   The typing time of the subject in seconds, measured from the entry of the first character to the entry of the last, including backspaces.
   * @author Markku Laine
   * @version 1.0
   * @see For more information, see "Words per Minute (WPM)" equation (Eq. 3.1) on page 49 of MacKenzie, I. S., & Tanaka-Ishii, K. (2010). Text entry systems: Mobility, accessibility, universality. Elsevier.
   */
  private def calculateWPM(inputLength: Int, inputTime: Double): Double = {
    val SECONDS_PER_MINUTE: Int = 60
    if (inputTime > 0) {
      ((inputLength - 1) / inputTime) * SECONDS_PER_MINUTE * (1 / configuration.underlying.getDouble("typingtest.averageWordLength"))
    }
    else {
      0.0
    }
  }

  def newUid(): Future[String] = {
    for {
      id <- databaseService.addParticipant(Participant())
      encryptedId <- cryptoService.encrypt(id.toString)
    } yield encryptedId
  }

  def newSentence(uid: String): Future[Map[String, String]] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      s <- databaseService.getRandomSentence(decryptedUid.toInt)
      tsId <- databaseService.addTestSection(TestSection(0, s(0).id, decryptedUid.toInt))
      encryptedTsId <-cryptoService.encrypt(tsId.toString)
    } yield Map("id" -> encryptedTsId, "sentence" -> s(0).sentence)
  }

  def getSentence(tsId: String): Future[Map[String, String]] = {
    for {
      decryptedTsId <- cryptoService.decrypt(tsId)
      (s) <- databaseService.getSentence(decryptedTsId.toInt)
    } yield Map("sentence" -> s(0).sentence)
  }

  def getAgeValues(uid: String): Future[(Int, Int, Int)] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      participantAge <- databaseService.getParticipantAge(decryptedUid.toInt)
    } yield {
      val age: Int = participantAge(0).getOrElse(0)
      val ageMin: Int = if (age == 0) 1 else (age / 10).toInt * 10
      val ageMax: Int = if (age == 0) 120 else ((age / 10).toInt + 1) * 10 - 1
      (age, ageMin, ageMax)
    }
  }

  def getWPM(uid: String): Future[Double] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      ts <- databaseService.getTestSections(decryptedUid.toInt)
    } yield {
      if (ts.nonEmpty) {
        val MILLISECONDS_PER_SECOND: Int = 1000
        val totalInputLength: Int = ts.foldLeft(0)((tot: Int, section) => tot + section.inputLength.get)
        val totalInputTime: Long = ts.foldLeft(0L)((tot: Long, section) => tot + section.inputTime.get)
        calculateWPM(totalInputLength, totalInputTime / (MILLISECONDS_PER_SECOND).toDouble)
      }
      else {
        0.0
      }
    }
  }

  def getErrorRate(uid: String): Future[Double] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      ts <- databaseService.getTestSections(decryptedUid.toInt)
    } yield {
      if (ts.nonEmpty) {
        val totalErrorLength: Int = ts.foldLeft(0)((tot: Int, section) => tot + section.errorLength.get)
        ts.foldLeft(0.0)((errorRate: Double, section) => errorRate + (section.errorRate.get * section.errorLength.get)) / totalErrorLength
      }
      else {
        0.0
      }
    }
  }

  def getMaxErrorRate(uid: String): Future[(Option[String], Option[String], Option[Int], Option[Double])] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      maxErrorRate <- databaseService.getMaxErrorRate(decryptedUid.toInt)
    }
      yield {
        if (maxErrorRate.head._3.get == 0) {
          (None, None, None, None)
        }
        else {
          val head = maxErrorRate.head
          (head._1, Some(head._2), head._3, head._4)
        }
      }
  }

  def getMaxWpm(uid: String): Future[(Option[String], Option[Int], Option[Double])] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      maxWpm <- databaseService.getMaxWpm(decryptedUid.toInt)
    }
    yield {
      val head = maxWpm.head
      (head._1, head._2, head._3)
    }
  }

  def getMinWpm(uid: String): Future[(Option[String], Option[Int], Option[Double])] = {
    for {
      decryptedUid <- cryptoService.decrypt(uid)
      minWpm <- databaseService.getMinWpm(decryptedUid.toInt)
    }
      yield {
        val head = minWpm.head
        (head._1, head._2, head._3)
      }
  }

  def submitLogData(testSection: String, logDataSubmit: Seq[LogDataSubmit]): Future[Unit]  = {
    val p = Promise[Unit]()
    Future {
      val logDataF = for {
        logDatas <- logDataSubmit
      } yield for {
        dTsId <- cryptoService.decrypt(testSection)
      } yield {
        LogData(0, dTsId.toInt, logDatas.eventTimestamp, logDatas.eventType, logDatas.eventKey, logDatas.eventCode, logDatas.eventData, logDatas.inputText, logDatas.keyCodes, logDatas.screenOrientation, logDatas.deviceOrientation)
      }
      val logData = Future.sequence(logDataF)
      logData.foreach(ld => {
        databaseService.addLogData(ld).onComplete{
          case success => {
            p.success((): Unit)
          }
        }
      })
    }
    p.future
  }

  def submitUserInput(tsId: String, userInput: String, device: String): Future[Unit] = {
    val p = Promise[Unit]()
    Future {
      for {
        dTsId <- cryptoService.decrypt(tsId)
        tsIdInt <- databaseService.updateUserInput(dTsId.toInt, userInput)
        logDatas <- databaseService.getLogDatas(dTsId.toInt)
        errorData <- databaseService.getDataForError(dTsId.toInt)
      } yield {
        databaseService.updateDevice(dTsId.toInt, device)

        val MILLISECONDS_PER_SECOND: Int = 1000
        val inputLength: Int = userInput.length
        val inputTime: Long = if (logDatas.length == 0) 0 else logDatas.last.eventTimestamp - logDatas.head.eventTimestamp
        val wpm: Double = calculateWPM(inputLength, inputTime / (MILLISECONDS_PER_SECOND).toDouble)
        // println(s"logDatas: ${logDatas.length}")
        // println(s"inputLength: ${inputLength}")
        // println(s"inputTime: ${inputTime}")
        // println(s"wpm: ${wpm}")

        databaseService.updateWpm(dTsId.toInt, inputLength, inputTime, wpm) onSuccess {
          case success => {
            // For more information, see "Minimum String Distance (MSD)" equation (Eq. 3.8) on page 54 of MacKenzie, I. S., & Tanaka-Ishii, K. (2010). Text entry systems: Mobility, accessibility, universality. Elsevier.
            val errorLength: Int = math.max(errorData(0)._1.get.length, errorData(0)._2.length)
            val editDistance: Int = calculateEditDistance(errorData(0)._1.get, errorData(0)._2)
            val errorRate: Double = ((editDistance).toDouble / (errorLength).toDouble) * (100).toDouble
            // println(s"errorLength: ${errorLength}")
            // println(s"editDistance: ${editDistance}")
            // println(s"errorRate: ${errorRate}")
            // println(s"")
            databaseService.updateErrorRate(dTsId.toInt, errorLength, editDistance, errorRate) onSuccess {
              case success => p.success((): Unit)
            }
          }
        }
      }
    }
    p.future
  }

  def updateUserStats(uid: String) = {
    for {
      dUid <- cryptoService.decrypt(uid)
      wpm <- getWPM(uid)
      errorRate <- getErrorRate(uid)
    } yield {
      databaseService.updateUserStats(dUid.toInt, wpm, errorRate)
    }
  }

  def submitBrowserData(uid: String, ipAddress: String, browserString: Option[String], browserLanguage: Option[String], device: Option[String], screenW: Option[Int], screenH: Option[Int]): Future[Unit] = {
    val p = Promise[Unit]()
    Future {
      cryptoService.decrypt(uid).foreach(participantId => 
        databaseService.updateBrowserData(participantId.toInt, ipAddress, browserString, browserLanguage, device, screenW, screenH).onComplete {
          case Success(result) =>  {
            p.success((): Unit)
          }
          case Failure(e) => e.printStackTrace
        }
      )
    }
    p.future
  }

  def submitUserData(uid: String, age: Int, gender: String, hasTakenTypingCourse: Boolean, nativeLanguage: String, keyboardType: String, usingApp: String, usingFeatures: String, fingers: String, timeSpentTyping: Int, typeTestLang: String): Future[Unit] = {
    val p = Promise[Unit]()
    Future {
      cryptoService.decrypt(uid).foreach(participantId => 
        databaseService.updatePersonalData(participantId.toInt, age, gender, hasTakenTypingCourse, nativeLanguage, keyboardType, usingApp, usingFeatures, fingers, timeSpentTyping, typeTestLang).onComplete {
          case Success(result) =>  {
            p.success((): Unit)
          }
          case Failure(e) => e.printStackTrace
        }
      )
    }
    p.future
  }

  // See https://gist.github.com/tixxit/1246894/e79fa9fbeda695b9e8a6a5d858b61ec42c7a367d
  def calculateEditDistance[A](a: Iterable[A], b: Iterable[A]): Int =
    ((0 to b.size).toList /: a)((prev, x) =>
      (prev zip prev.tail zip b).scanLeft(prev.head + 1) {
        case (h, ((d, v), y)) => min(min(h + 1, v + 1), d + (if (x == y) 0 else 1))
      }) last

  def getTestSections(device: String): Future[Seq[TestSection]] = {
    for {
      (testsections) <- databaseService.listTestSections(device)
    } yield testsections
  }

  def getWpmHistogramData(device: String): Future[Seq[(Int, Int)]] = {
    for {
      wpmHistogramData <- databaseService.getWpmHistogramData(device)
    } yield wpmHistogramData
  }

  def getWpmAgeHistogramData(ageMin: Int, ageMax: Int, device: String): Future[Seq[(Int, Int)]] = {
    for {
      wpmAgeHistogramData <- databaseService.getWpmAgeHistogramData(ageMin, ageMax, device)
    } yield wpmAgeHistogramData
  }

  def getErrorRateHistogramData(device: String): Future[Seq[(Int, Int)]] = {
    for {
      errorRateHistogramData <- databaseService.getErrorRateHistogramData(device)
    } yield errorRateHistogramData
  }
}
