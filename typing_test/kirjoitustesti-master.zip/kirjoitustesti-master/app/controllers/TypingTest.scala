package controllers

import javax.inject._

import models.TestResults
import models.TestSection
import play.api._
import play.api.data.Form
import play.api.data.Forms._
import play.api.mvc._
import play.api.routing._
import play.api.libs.json._
import play.api.libs.functional.syntax._
import play.api.libs.ws.WSClient
import services.TypingTestService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

case class LogDataSubmit(eventTimestamp: Long, eventType: String, eventKey: String, eventCode: String, eventData: String, inputText: String, keyCodes: String, screenOrientation: String, deviceOrientation: String)
case class QuestionnaireData(age: Int, gender: String, hasTakenTypingCourse: String, nativeLanguage: String, keyboardType: String, usingApp: String, usingFeatures: String, fingers: String, timeSpentTyping: Int, typeTestLang: String)
case class WpmHistogramData(bucket: Int, count: Int)
case class WpmAgeHistogramData(bucket: Int, count: Int)
case class ErrorRateHistogramData(bucket: Int, count: Int)

@Singleton
class TypingTest @Inject()(testService: TypingTestService, ws: WSClient) extends Controller {

  case class QuestionnaireDataSubmit(age: Int, gender: String, hasTakenTypingCourse: String, nativeLanguage: String, keyboardType: String, usingApp: String, usingFeatures: String, fingers: String, timeSpentTyping: Int, typeTestLang: String)

  val uidMissingResponse = BadRequest(Json.toJson(Map("status" -> "Bad Request", "error" -> "uid_missing_err")))
  val tsidMissingResponse = BadRequest(Json.toJson(Map("status" -> "Bad Request", "error" -> "tsid_missing_err")))
  val validationErrorResponse = BadRequest(Json.toJson(Map("status" -> "Bad Request", "error" -> "validation_err")))

  def consent = Action { implicit request =>
    Ok(views.html.consent(request)).withHeaders("P3P" -> "CP=\"Deprecated\"")
  }

  def instructions = Action { implicit request =>
    Ok(views.html.instructions(request)).withHeaders("P3P" -> "CP=\"Deprecated\"")
  }

  def typingTest = Action { implicit request =>
    Ok(views.html.typingtest(request)).withHeaders("P3P" -> "CP=\"Deprecated\"")
  }

  def questionnaire = Action { implicit request =>
    Ok(views.html.questionnaire(questionnaireForm)).withHeaders("P3P" -> "CP=\"Deprecated\"")
  }

  def uidErr = Action { implicit request =>
    Ok(views.html.uidErr(request)).withHeaders("P3P" -> "CP=\"Deprecated\"")
  }

  val questionnaireForm = Form(
    mapping(
      "age" -> number(min = 1, max = 120),
      "gender" -> text,
      "hasTakenTypingCourse" -> text,
      "nativeLanguage" -> text,
      "keyboardType" -> text,  
      "usingApp" -> text, 
      "usingFeatures" -> text,
      "fingers" -> text,
      "timeSpentTyping" -> number(min = 0, max = 24),
      "typeTestLang" -> text
    )(QuestionnaireData.apply)(QuestionnaireData.unapply)
  )

  def results = Action.async { implicit request =>
    request.session.get("uid") match {
      case Some(uid) => {
        for {
          wpm <- testService.getWPM(uid)
          errorRate <- testService.getErrorRate(uid)
          maxErrorRate <- testService.getMaxErrorRate(uid) // _1: userInput, _2: sentence, _3: editDistance, _4: wpm
          maxWpm <- testService.getMaxWpm(uid) // _1: userInput, _2: editDistance, _3: wpm
          minWpm <- testService.getMinWpm(uid) // _1: userInput, _2: editDistance, _3: wpm
        } yield {
          (maxWpm, minWpm) match {
            case ((Some(maxWpmUserInput), Some(maxWpmEditDistance), Some(maxWpmWpm)), (Some(minWpmUserInput), Some(minWpmEditDistance), Some(minWpmWpm))) => {
              Ok(views.html.results(TestResults(wpm, errorRate, maxErrorRate._1, maxErrorRate._2, maxErrorRate._3, maxErrorRate._4, maxWpmUserInput, maxWpmEditDistance, maxWpmWpm, minWpmUserInput, minWpmEditDistance, minWpmWpm)))
                .withHeaders(CACHE_CONTROL -> "no-cache", "P3P" -> "CP=\"Deprecated\"")
            }
          }
        }
      }
      case None => Future(uidMissingResponse)
    }
  }

  def typingtestRoutes = Action { implicit request =>
    Ok(
        JavaScriptReverseRouter("typingtestRoutes")(
          routes.javascript.TypingTest.newUid,
          routes.javascript.TypingTest.sentence,
          routes.javascript.TypingTest.getWPM,
          routes.javascript.TypingTest.getErrorRate,
          routes.javascript.TypingTest.updateStats
        )
    ).as("text/javascript")
  }

  def newUid = Action.async { implicit request =>
    testService.newUid().map(s => {
      Ok(Json.toJson(Map("uid" -> s)))
        .withSession("uid" -> s)
        .withHeaders(CACHE_CONTROL -> "no-cache")
    })
  }

  def sentence(first: Boolean) = Action.async {
    implicit request => {
      (request.session.get("uid"), request.session.get("count"), request.session.get("tsid"),first) match {
        // new sentence in the middle of the test
        case (Some(uid), Some(count), _, false) => testService.newSentence(uid).map(map => {
          map.get("id") match {
            case Some(id) => Ok(Json.toJson(map + ("count" -> (count.toInt + 1).toString)))
              .withSession(request.session + ("count" -> (count.toInt + 1).toString) + ("tsid" -> id))
              .withHeaders(CACHE_CONTROL -> "no-cache")
            case _ => tsidMissingResponse
          }
        })
        // new sentence at the beginning of the test
        case (Some(uid), None, _, true) => testService.newSentence(uid).map(map => {
          map.get("id") match {
            case Some(id) => Ok(Json.toJson(map + ("count" -> (1).toString)))
              .withSession(request.session + ("count" -> "1") + ("tsid" -> id))
              .withHeaders(CACHE_CONTROL -> "no-cache")
            case _ => tsidMissingResponse
          }
        })
        // old sentence
        case (Some(uid), Some(count), Some(tsid), true) => testService.getSentence(tsid).map(map => {
          Ok(Json.toJson(map + ("count" -> count)))
            .withSession(request.session + ("count" -> count) + ("tsid" -> tsid))
            .withHeaders(CACHE_CONTROL -> "no-cache")
        })
        case _ => Future(uidMissingResponse)
      }
    }
  }

  def updateStats = Action {
    implicit request => {
      request.session.get("uid") match {
        case Some(uid) => {
          request.session.get("questionnaire") match {
            case Some(q) => {
              testService.updateUserStats(uid)
              Ok(Json.toJson(Map("status" -> "OK", "questionnaire" -> "true"))).withSession(request.session - "count")
            }
            case None => {
              testService.updateUserStats(uid)
              Ok(Json.toJson(Map("status" -> "OK", "questionnaire" -> "false"))).withSession(request.session - "count")
            }
          }
        }
        case None => uidMissingResponse
      }
    }
  }

  def getAgeValues = Action.async {
    implicit request => {
      request.session.get("uid") match {
        case Some(uid) => testService.getAgeValues(uid).map({ case (age, ageMin, ageMax) => Ok(Json.toJson(Map("age" -> age, "ageMin" -> ageMin, "ageMax" -> ageMax))).withHeaders(CACHE_CONTROL -> "no-cache")})
        case None => Future(uidMissingResponse)
      }
    }
  }

  def getWPM = Action.async {
    implicit request => {
      request.session.get("uid") match {
        case Some(uid) => testService.getWPM(uid).map(wpm => Ok(Json.toJson(Map("wpm" -> wpm))).withHeaders(CACHE_CONTROL -> "no-cache"))
        case None => Future(uidMissingResponse)
      }
    }
  }

  def getErrorRate = Action.async {
    implicit request => {
      request.session.get("uid") match {
        case Some(uid) => testService.getErrorRate(uid).map(errorRate => Ok(Json.toJson(Map("errorRate" -> errorRate))).withHeaders(CACHE_CONTROL -> "no-cache"))
        case None => Future(uidMissingResponse)
      }
    }
  }

  def saveLogData = Action.async(BodyParsers.parse.json) {
    implicit request => {
      val logData = (request.body \ "logData").as[Seq[LogDataSubmit]]
      request.session.get("tsid") match {
        case Some(tsid) => {
          testService.submitLogData(tsid, logData).map {
            unit => {
              Ok(Json.obj("status" -> "OK"))
            }
          }
        }
        case None => Future(tsidMissingResponse)
      }
    }
  }

  def saveUserInput = Action.async(BodyParsers.parse.json) {
    request => {
      val userInput = (request.body \ "userInput").as[String]
      val device = (request.body \ "device").as[String]
      request.session.get("tsid") match {
        case Some(tsid) => {
          testService.submitUserInput(tsid, userInput, device).map(unit => {
            Ok(Json.obj("status" -> "OK"))
          })
        }
        case None => Future(tsidMissingResponse)
      }
    }
  }


  def saveBrowserData = Action.async(BodyParsers.parse.json) {
    implicit request => {
      val ipAddress: String = request.remoteAddress
      val browserLanguage: Option[String] = request.headers.get("Accept-Language")
      val browserString: Option[String] = request.headers.get("User-Agent")
      val device = (request.body \ "device").as[String]
      val screenW = (request.body \ "screenW").as[Int]
      val screenH = (request.body \ "screenH").as[Int]
      request.session.get("uid") match {
        case Some(uid) => {
          testService.submitBrowserData(uid, ipAddress, browserString, browserLanguage, Some(device), Some(screenW), Some(screenH)).map{
              unit => {
                Ok(Json.obj("status" -> "OK"))
              }
            }
        }
        case None => Future(tsidMissingResponse)
      }
    }
  }

  def questionnairePost = Action.async(BodyParsers.parse.json) {
    implicit request => {
      val ud = (request.body).as[QuestionnaireDataSubmit]
      request.session.get("uid") match {
        case Some(uid) => {
          testService.submitUserData(
            uid,
            ud.age,
            ud.gender,
            ud.hasTakenTypingCourse.toBoolean,
            ud.nativeLanguage,
            ud.keyboardType,
            ud.usingApp,
            ud.usingFeatures,
            ud.fingers,
            ud.timeSpentTyping,
            ud.typeTestLang
          ).map {
            unit => {
              Ok(Json.obj("status" -> "OK")).withSession(request.session + ("questionnaire" -> "done"))
            }
          }
        }
        case None => Future(tsidMissingResponse)
      }
    }
  }

  def getWpmHistogramData(device: String) = Action.async { implicit request =>
    for {
      wpmHistogramData <- testService.getWpmHistogramData(device)
    } yield {
      Ok(Json.toJson(for (entry <- wpmHistogramData) yield {
        val bucket: Int = entry._1
        val count: Int = entry._2
        WpmHistogramData(bucket, count)
      }))
    }
  }

  def getWpmAgeHistogramData(device: String) = Action.async {
    implicit request => {
      request.session.get("uid") match {
        case Some(uid) => {
          for {
            ageValues <- testService.getAgeValues(uid)
            wpmAgeHistogramData <- testService.getWpmAgeHistogramData(ageValues._2, ageValues._3, device)
          } yield {
            Ok(Json.toJson(for (entry <- wpmAgeHistogramData) yield {
              val bucket: Int = entry._1
              val count: Int = entry._2
              WpmAgeHistogramData(bucket, count)
            }))
          }
        }
        case None => Future(uidMissingResponse)
      }
    }
  }

  def getErrorRateHistogramData(device: String) = Action.async { implicit request =>
    for {
      errorRateHistogramData <- testService.getErrorRateHistogramData(device)
    } yield {
      Ok(Json.toJson(for (entry <- errorRateHistogramData) yield {
        val bucket: Int = entry._1
        val count: Int = entry._2
        ErrorRateHistogramData(bucket, count)
      }))
    }
  }

  implicit val wpmHistogramDataWrites: Writes[WpmHistogramData] = Json.writes[WpmHistogramData]
  implicit val wpmAgeHistogramDataWrites: Writes[WpmAgeHistogramData] = Json.writes[WpmAgeHistogramData]
  implicit val errorRateHistogramDataWrites: Writes[ErrorRateHistogramData] = Json.writes[ErrorRateHistogramData]

  implicit val TestSectionWrites: Writes[TestSection] = (
    (JsPath \ "id").write[Int] and
    (JsPath \ "sentenceId").write[Int] and
    (JsPath \ "participantId").write[Int] and
    (JsPath \ "userInput").writeNullable[String] and
    (JsPath \ "inputLength").writeNullable[Int] and
    (JsPath \ "inputTime").writeNullable[Long] and
    (JsPath \ "wpm").writeNullable[Double] and
    (JsPath \ "errorLength").writeNullable[Int] and
    (JsPath \ "editDistance").writeNullable[Int] and
    (JsPath \ "errorRate").writeNullable[Double] and
    (JsPath \ "device").writeNullable[String] 
  )(unlift(TestSection.unapply))

  implicit val logDataSubmitReads: Reads[LogDataSubmit] = (
    (JsPath \ "eventTimestamp").read[Long] and
    (JsPath \ "eventType").read[String] and
    (JsPath \ "eventKey").read[String] and
    (JsPath \ "eventCode").read[String] and
    (JsPath \ "eventData").read[String] and
    (JsPath \ "inputText").read[String] and
    (JsPath \ "keyCodes").read[String] and
    (JsPath \ "screenOrientation").read[String] and
    (JsPath \ "deviceOrientation").read[String]
  )(LogDataSubmit.apply _)

  implicit val questionnaireDataSubmitReads: Reads[QuestionnaireDataSubmit] = (
    (JsPath \ "age").read[Int] and
    (JsPath \ "gender").read[String] and
    (JsPath \ "hasTakenTypingCourse").read[String] and
    (JsPath \ "nativeLanguage").read[String] and
    (JsPath \ "keyboardType").read[String] and
    (JsPath \ "usingApp").read[String] and
    (JsPath \ "usingFeatures").read[String] and
    (JsPath \ "fingers").read[String] and
    (JsPath \ "timeSpentTyping").read[Int] and
    (JsPath \ "typeTestLang").read[String]
  )(QuestionnaireDataSubmit.apply _)
}
